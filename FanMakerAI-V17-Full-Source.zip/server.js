import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';
import archiver from 'archiver';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { fileURLToPath } from 'url';

const execFileAsync = promisify(execFile);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const DATA = path.join(__dirname, 'data');
const MEDIA = path.join(DATA, 'media');
const DB = path.join(DATA, 'db.json');
fs.mkdirSync(MEDIA, { recursive: true });
const emptyDb = { users: [], sessions: [], messages: [], jobs: [], payments: [], settings: {} };
let db = fs.existsSync(DB) ? JSON.parse(fs.readFileSync(DB, 'utf8')) : emptyDb;
function save(){ const tmp=DB+'.tmp'; fs.writeFileSync(tmp, JSON.stringify(db,null,2)); fs.renameSync(tmp,DB); }
const openai = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;
const ownerId=process.env.ADMIN_USER_ID||'owner';
const freeLimit=Math.max(0,Number(process.env.FREE_DAILY_GENERATIONS||5));
const maxUpload=Math.max(1,Number(process.env.MAX_UPLOAD_MB||60))*1024*1024;
const sessionDays=Math.max(1,Number(process.env.SESSION_DAYS||30));
const rlWindow=Math.max(1000,Number(process.env.RATE_LIMIT_WINDOW_MS||60000));
const rlMax=Math.max(5,Number(process.env.RATE_LIMIT_MAX||60));
const buckets=new Map();
const id=()=>crypto.randomUUID();
const now=()=>new Date().toISOString();
function rateLimit(req,res,next){
  const key=(req.ip||'unknown')+'|'+req.path; const t=Date.now(); let b=buckets.get(key);
  if(!b||t-b.start>rlWindow)b={start:t,count:0}; b.count++; buckets.set(key,b);
  if(b.count>rlMax)return res.status(429).json({error:'Too many requests. Please try again shortly.'}); next();
}
app.use(express.json({limit:'80mb',verify:(req,res,buf)=>{if(req.path==='/api/payments/webhook')req.rawBody=Buffer.from(buf)}}));
app.use(express.urlencoded({extended:true,limit:'80mb'}));
app.use((req,res,next)=>{const origin=req.get('origin')||'*';res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization, X-Admin-Token');res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS');if(req.method==='OPTIONS')return res.sendStatus(204);next()});
app.use(rateLimit);
app.use(express.static(path.join(__dirname,'public')));
function passwordHash(password,salt=crypto.randomBytes(16).toString('hex')){return{salt,hash:crypto.scryptSync(password,salt,64).toString('hex')}}
function cleanSessions(){const t=Date.now();db.sessions=db.sessions.filter(s=>Date.parse(s.expiresAt)>t);}
function auth(req,res,next){cleanSessions();const token=(req.get('authorization')||'').replace(/^Bearer\s+/i,'');const s=db.sessions.find(x=>x.token===token);if(!s)return res.status(401).json({error:'Login required'});const u=db.users.find(x=>x.id===s.userId);if(!u)return res.status(401).json({error:'Session invalid'});req.user=u;req.session=s;next()}
function optionalAuth(req,res,next){const token=(req.get('authorization')||'').replace(/^Bearer\s+/i,'');const s=db.sessions.find(x=>x.token===token);req.user=s?db.users.find(x=>x.id===s.userId):null;req.session=s;next()}
function isOwner(req){return req.user?.role==='owner'||(process.env.ADMIN_API_TOKEN&&req.get('x-admin-token')===process.env.ADMIN_API_TOKEN)}
function needOpenAI(){if(!openai)throw Error('OPENAI_API_KEY is not configured on the server.')}
function safeName(ext='bin'){return `${id()}.${String(ext).replace(/[^a-z0-9]/gi,'').slice(0,8)||'bin'}`}
function mediaPath(name){const base=path.basename(decodeURIComponent(String(name||'')));const p=path.join(MEDIA,base);if(!p.startsWith(MEDIA+path.sep)||!fs.existsSync(p))throw Error('Media not found.');return p}
function mimeFor(name){const ext=path.extname(name).toLowerCase();return ({'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.mp4':'video/mp4','.webm':'video/webm','.mp3':'audio/mpeg','.wav':'audio/wav','.m4a':'audio/mp4'})[ext]||'application/octet-stream'}
function recordJob(j){db.jobs.push({...j,id:j.id||id(),day:new Date().toISOString().slice(0,10),createdAt:j.createdAt||now()});save()}
function dailyCount(uid){const d=new Date().toISOString().slice(0,10);return db.jobs.filter(j=>j.userId===uid&&j.day===d&&j.kind!=='chat').length}
function quota(req){if(req.user.role==='owner'||req.user.premium)return;if(dailyCount(req.user.id)>=freeLimit)throw Error(`Daily free generation limit reached (${freeLimit}).`)}
async function ffmpeg(args){try{await execFileAsync('ffmpeg',['-y',...args],{maxBuffer:20*1024*1024});}catch(e){if(e.code==='ENOENT')throw Error('FFmpeg is not installed on the server. Use the included Dockerfile or install FFmpeg.');throw e}}
async function download(url,out){const r=await fetch(url);if(!r.ok)throw Error(`Download failed ${r.status}`);const b=Buffer.from(await r.arrayBuffer());if(b.length>maxUpload)throw Error('Generated media is too large.');fs.writeFileSync(out,b);return out}
function saveDataUrl(dataUrl,extHint='bin'){const m=String(dataUrl||'').match(/^data:([^;]+);base64,(.+)$/s);if(!m)throw Error('Expected a base64 data URL.');const allowed=new Set(['image/png','image/jpeg','image/webp','video/mp4','video/webm','audio/mpeg','audio/wav','audio/mp4']);if(!allowed.has(m[1]))throw Error('Unsupported media type.');const b=Buffer.from(m[2],'base64');if(b.length>maxUpload)throw Error('File is too large.');const ext=(m[1].split('/')[1]||extHint).split('+')[0].replace(/[^a-z0-9]/gi,'').slice(0,8)||extHint;const name=safeName(ext);fs.writeFileSync(path.join(MEDIA,name),b);return name}
async function watermark(src,out,text='FanMakerAI'){const clean=String(text).replace(/[^\w\s-]/g,'').slice(0,40)||'FanMakerAI';await ffmpeg(['-i',src,'-vf',`drawtext=text='${clean}':x=w-tw-24:y=h-th-20:fontsize=24:fontcolor=white@0.78:box=1:boxcolor=black@0.28:boxborderw=8`,'-c:a','copy',out])}
function hmac(secret,body){return crypto.createHmac('sha256',secret).update(body).digest('hex')}
app.get('/api/health',(req,res)=>res.json({ok:true,version:'15.0.0',features:{chat:true,webSearch:true,image:true,video:true,tts:true,musicAdapter:true,media:true,ffmpeg:true,auth:true,paymentWebhook:true}}));
app.get('/api/diagnostics',optionalAuth,(req,res)=>{if(!isOwner(req))return res.status(403).json({error:'Owner only'});let ff=true;try{require('child_process').execFileSync('ffmpeg',['-version'],{stdio:'ignore'})}catch{ff=false}res.json({node:process.version,ffmpeg:ff,openai:!!openai,music:!!(process.env.MUSIC_API_URL&&process.env.MUSIC_API_KEY),payment:!!process.env.PAYMENT_CHECKOUT_URL,storage:fs.existsSync(MEDIA),db:fs.existsSync(DB),freeDailyGenerations:freeLimit,maxUploadMB:maxUpload/1024/1024})});
app.post('/api/auth/register',(req,res)=>{try{const email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||''),username=String(req.body.username||'').trim().toLowerCase(),fullName=String(req.body.fullName||'').trim(),age=Number(req.body.age||0);if(!/^\S+@\S+\.\S+$/.test(email)||password.length<8)return res.status(400).json({error:'Valid email and 8+ character password required.'});if(!/^[a-z0-9_]{3,24}$/.test(username))return res.status(400).json({error:'Username must be 3-24 characters: a-z, 0-9, underscore.'});if(!fullName)return res.status(400).json({error:'Full Name is required.'});if(db.users.some(u=>u.email===email))return res.status(409).json({error:'Account already exists.'});if(db.users.some(u=>u.username===username))return res.status(409).json({error:'Username already exists.'});const h=passwordHash(password),u={id:id(),email,username,fullName,age,role:'user',premium:false,fans:0,emailVerified:false,verifyToken:crypto.randomBytes(24).toString('hex'),...h,createdAt:now()};db.users.push(u);save();const base=process.env.PUBLIC_BASE_URL||`${req.protocol}://${req.get('host')}`;res.json({ok:true,userId:u.id,verificationUrl:`${base}/api/auth/verify?token=${u.verifyToken}`})}catch(e){res.status(500).json({error:e.message})}});
const googleStates=new Map();
app.get('/api/auth/google/start',(req,res)=>{
  if(!process.env.GOOGLE_CLIENT_ID||!process.env.GOOGLE_CLIENT_SECRET||!process.env.GOOGLE_REDIRECT_URI)
    return res.status(503).send('Google sign-in is not configured on the server.');
  const state=crypto.randomBytes(24).toString('hex');
  googleStates.set(state,{expires:Date.now()+10*60*1000});
  const u=new URL('https://accounts.google.com/o/oauth2/v2/auth');
  u.searchParams.set('client_id',process.env.GOOGLE_CLIENT_ID);
  u.searchParams.set('redirect_uri',process.env.GOOGLE_REDIRECT_URI);
  u.searchParams.set('response_type','code');
  u.searchParams.set('scope','openid email profile');
  u.searchParams.set('state',state);
  u.searchParams.set('prompt','select_account');
  res.redirect(u.toString());
});
app.get('/api/auth/google/callback',async(req,res)=>{
  try{
    const state=String(req.query.state||''),code=String(req.query.code||'');
    const saved=googleStates.get(state); googleStates.delete(state);
    if(!saved||saved.expires<Date.now()||!code)return res.status(400).send('Google sign-in session expired.');
    const body=new URLSearchParams({code,client_id:process.env.GOOGLE_CLIENT_ID,client_secret:process.env.GOOGLE_CLIENT_SECRET,redirect_uri:process.env.GOOGLE_REDIRECT_URI,grant_type:'authorization_code'});
    const tr=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
    const td=await tr.json(); if(!tr.ok)throw Error(td.error_description||'Google token exchange failed.');
    const ur=await fetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:`Bearer ${td.access_token}`}});
    const g=await ur.json(); if(!ur.ok||!g.email||g.email_verified!==true)throw Error('Google account email is not verified.');
    const email=String(g.email).toLowerCase(); let u=db.users.find(x=>x.googleId===g.sub||x.email===email);
    if(u){u.googleId=g.sub;u.emailVerified=true;u.fullName=u.fullName||g.name||'';u.avatar=u.avatar||g.picture||'';}
    else{
      let base=(g.name||email.split('@')[0]).toLowerCase().replace(/[^a-z0-9_]/g,'').slice(0,18)||'user'; let username=base,n=1;
      while(db.users.some(x=>x.username===username))username=(base+(n++)).slice(0,24);
      u={id:id(),email,username,fullName:g.name||base,age:0,role:'user',premium:false,fans:0,googleId:g.sub,emailVerified:true,avatar:g.picture||'',createdAt:now()};db.users.push(u);
    }
    const token=crypto.randomBytes(32).toString('hex');db.sessions.push({token,userId:u.id,expiresAt:new Date(Date.now()+sessionDays*864e5).toISOString()});save();
    const base=process.env.PUBLIC_BASE_URL||`${req.protocol}://${req.get('host')}`;const redirect=new URL(base);redirect.searchParams.set('google_token',token);redirect.searchParams.set('google_email',u.email);redirect.searchParams.set('google_name',u.fullName||'Google User');res.redirect(redirect.toString());
  }catch(e){res.status(400).send(e.message)}
});
app.post('/api/auth/login',(req,res)=>{try{const email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||'');let u=db.users.find(x=>x.email===email);if(!u&&process.env.ADMIN_EMAIL&&email===process.env.ADMIN_EMAIL&&process.env.ADMIN_PASSWORD&&password===process.env.ADMIN_PASSWORD){const h=passwordHash(password);u={id:ownerId,email,role:'owner',premium:true,fans:0,...h,createdAt:now()};db.users.push(u)}if(!u)return res.status(401).json({error:'Invalid credentials.'});if(u.emailVerified===false)return res.status(403).json({error:'Email is not verified. Open the verification link sent by the server.'});const test=crypto.scryptSync(password,u.salt,64).toString('hex');if(!crypto.timingSafeEqual(Buffer.from(test,'hex'),Buffer.from(u.hash,'hex')))return res.status(401).json({error:'Invalid credentials.'});const token=crypto.randomBytes(32).toString('hex');db.sessions.push({token,userId:u.id,expiresAt:new Date(Date.now()+sessionDays*864e5).toISOString()});save();res.json({token,user:{id:u.id,email:u.email,username:u.username||'',fullName:u.fullName||'',age:u.age||0,role:u.role,premium:u.premium,fans:u.fans}})}catch(e){res.status(500).json({error:e.message})}});
app.get('/api/auth/verify',(req,res)=>{const t=String(req.query.token||'');const u=db.users.find(x=>x.verifyToken===t);if(!u)return res.status(400).send('Invalid or expired verification link.');u.emailVerified=true;delete u.verifyToken;save();res.send('<h2>Email verified</h2><p>You can return to FanMakerAI and log in.</p>')});
app.post('/api/auth/logout',auth,(req,res)=>{db.sessions=db.sessions.filter(s=>s.token!==req.session.token);save();res.json({ok:true})});
app.get('/api/me',auth,(req,res)=>res.json({userId:req.user.id,email:req.user.email,username:req.user.username||'',fullName:req.user.fullName||'',age:req.user.age||0,role:req.user.role,premium:req.user.premium,fans:req.user.fans}));
app.put('/api/profile',auth,(req,res)=>{try{const fullName=String(req.body.fullName||'').trim(),username=String(req.body.username||'').trim().toLowerCase(),age=Number(req.body.age||0);if(!fullName||!/^[a-z0-9_]{3,24}$/.test(username))return res.status(400).json({error:'Valid name and username required.'});if(db.users.some(u=>u.username===username&&u.id!==req.user.id))return res.status(409).json({error:'Username already exists.'});req.user.fullName=fullName;req.user.username=username;req.user.age=age;save();res.json({ok:true,profile:{email:req.user.email,username,fullName,age,role:req.user.role,premium:req.user.premium,fans:req.user.fans}})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/chat',auth,async(req,res)=>{try{needOpenAI();const message=String(req.body.message||'').trim();if(!message)return res.status(400).json({error:'Message required.'});const hist=Array.isArray(req.body.history)?req.body.history.slice(-30):[];const input=[...hist.map(x=>({role:x.role==='assistant'?'assistant':'user',content:String(x.content||'')})),{role:'user',content:message}];const r=await openai.responses.create({model:process.env.OPENAI_MODEL||'gpt-5.6-luna',tools:[{type:'web_search'}],instructions:'You are FanMakerAI. Answer accurately and helpfully in the user language. You can research current information with web search. Never claim an image, video, music, payment, or app action happened unless the server actually returned success.',input,store:false});const text=r.output_text||'No response.';db.messages.push({userId:req.user.id,role:'user',content:message,at:now()},{userId:req.user.id,role:'assistant',content:text,at:now()});save();res.json({text})}catch(e){res.status(500).json({error:e.message})}});
app.get('/api/chat/history',auth,(req,res)=>res.json(db.messages.filter(x=>x.userId===req.user.id).slice(-300)));
app.post('/api/prompt',auth,async(req,res)=>{try{needOpenAI();const text=String(req.body.text||'').trim(),type=String(req.body.type||'general');if(!text)return res.status(400).json({error:'Prompt text required.'});const r=await openai.responses.create({model:process.env.OPENAI_MODEL||'gpt-5.6-luna',instructions:`You are a professional prompt engineer for FanMakerAI. Turn the rough idea into one production-ready prompt for ${type}. Include subject, action, composition, camera/lens, lighting, environment, realism, materials, motion, constraints and aspect ratio when useful. Do not invent a specific person's identity. Return only the polished prompt.`,input:text,store:false});res.json({prompt:r.output_text||text})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/image',auth,async(req,res)=>{try{quota(req);needOpenAI();const prompt=String(req.body.prompt||'').trim();if(!prompt)return res.status(400).json({error:'Prompt required.'});const r=await openai.images.generate({model:process.env.OPENAI_IMAGE_MODEL||'gpt-image-2',prompt,size:req.body.size||'1024x1024',quality:req.body.quality||'high'});const item=r.data?.[0];let name;if(item?.b64_json){name=saveDataUrl(`data:image/png;base64,${item.b64_json}`,'png')}else if(item?.url){name=safeName('png');await download(item.url,path.join(MEDIA,name))}else throw Error('Image provider returned no image.');recordJob({userId:req.user.id,kind:'image',provider:'openai',status:'succeeded',output:name});res.json({status:'succeeded',mediaUrl:`/api/media/file/${name}`,name})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/video',auth,async(req,res)=>{try{quota(req);needOpenAI();const prompt=String(req.body.prompt||'').trim();if(!prompt)return res.status(400).json({error:'Prompt required.'});const r=await fetch('https://api.openai.com/v1/videos',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.SORA_MODEL||'sora-2',prompt,seconds:String(req.body.seconds||4),size:req.body.size||'720x1280'})});const d=await r.json();if(!r.ok)throw Error(d?.error?.message||`Video API ${r.status}`);recordJob({id:d.id,userId:req.user.id,kind:'video',provider:'openai',providerId:d.id,status:d.status});res.json(d)}catch(e){res.status(500).json({error:e.message})}});
app.get('/api/video/:id',auth,async(req,res)=>{try{const j=db.jobs.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!j)return res.status(404).json({error:'Job not found.'});needOpenAI();const r=await fetch(`https://api.openai.com/v1/videos/${req.params.id}`,{headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`}});const d=await r.json();if(!r.ok)throw Error(d?.error?.message||`Video API ${r.status}`);j.status=d.status;save();res.json(d)}catch(e){res.status(500).json({error:e.message})}});
app.get('/api/video/:id/content',auth,async(req,res)=>{try{const j=db.jobs.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!j)return res.status(404).end();needOpenAI();const r=await fetch(`https://api.openai.com/v1/videos/${req.params.id}/content`,{headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`}});if(!r.ok)return res.status(r.status).send(await r.text());res.setHeader('Content-Type',r.headers.get('content-type')||'video/mp4');res.send(Buffer.from(await r.arrayBuffer()))}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/transcribe',auth,async(req,res)=>{try{needOpenAI();const data=String(req.body.dataUrl||'');const m=data.match(/^data:(audio\/[^;]+);base64,(.+)$/s);if(!m)return res.status(400).json({error:'Audio data required.'});const ext=(m[1].split('/')[1]||'webm').split('+')[0];const tmp=path.join(MEDIA,safeName(ext));fs.writeFileSync(tmp,Buffer.from(m[2],'base64'));const tr=await openai.audio.transcriptions.create({file:fs.createReadStream(tmp),model:process.env.TRANSCRIBE_MODEL||'gpt-4o-transcribe'});fs.unlinkSync(tmp);res.json({text:tr.text||''})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/tts',auth,async(req,res)=>{try{needOpenAI();const text=String(req.body.text||'').trim();if(!text)return res.status(400).json({error:'Text required.'});const r=await fetch('https://api.openai.com/v1/audio/speech',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:req.body.model||process.env.TTS_MODEL||'gpt-4o-mini-tts',voice:req.body.voice||'alloy',input:text,response_format:'mp3'})});if(!r.ok)return res.status(r.status).send(await r.text());res.setHeader('Content-Type','audio/mpeg');res.send(Buffer.from(await r.arrayBuffer()))}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/music',auth,async(req,res)=>{try{quota(req);const prompt=String(req.body.prompt||'').trim();if(!prompt)return res.status(400).json({error:'Prompt required.'});if(!process.env.MUSIC_API_URL||!process.env.MUSIC_API_KEY)return res.status(503).json({error:'Music provider is not configured. Add a licensed provider endpoint/key in .env.'});const r=await fetch(process.env.MUSIC_API_URL,{method:'POST',headers:{Authorization:`Bearer ${process.env.MUSIC_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({prompt,duration:Number(req.body.duration||30)})});const d=await r.json();if(!r.ok)throw Error(d?.error||`Music provider ${r.status}`);recordJob({userId:req.user.id,kind:'music',provider:'external',status:d.status||'submitted',output:d});res.json(d)}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/media/upload',auth,(req,res)=>{try{const name=saveDataUrl(req.body.dataUrl,req.body.ext||'bin');res.json({ok:true,name,mediaUrl:`/api/media/file/${name}`})}catch(e){res.status(400).json({error:e.message})}});
app.get('/api/media',auth,(req,res)=>res.json(fs.readdirSync(MEDIA).map(name=>({name,mediaUrl:`/api/media/file/${encodeURIComponent(name)}`,mime:mimeFor(name)}))));
app.get('/api/media/file/:name',auth,(req,res)=>{try{const p=mediaPath(req.params.name);res.setHeader('Content-Type',mimeFor(p));res.setHeader('Cache-Control','private, max-age=3600');res.sendFile(p)}catch(e){res.status(404).json({error:e.message})}});
app.get('/api/history',auth,(req,res)=>res.json(db.jobs.filter(x=>x.userId===req.user.id).slice(-200)));
app.post('/api/gif',auth,async(req,res)=>{try{const name=path.basename(String(req.body.mediaUrl||'').split('/').pop());const src=mediaPath(name),outName=safeName('gif');await ffmpeg(['-loop','1','-i',src,'-t','2','-vf','fps=10,scale=480:-1:flags=lanczos,format=rgba','-gifflags','-transdiff',path.join(MEDIA,outName)]);res.json({mediaUrl:`/api/media/file/${outName}`,name:outName})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/watermark',auth,async(req,res)=>{try{if(req.user.premium||req.user.role==='owner')return res.json({mediaUrl:req.body.mediaUrl,skipped:true});const name=path.basename(String(req.body.mediaUrl||'').split('/').pop());const src=mediaPath(name),outName=safeName('mp4');await watermark(src,path.join(MEDIA,outName),req.body.text||'FanMakerAI');res.json({mediaUrl:`/api/media/file/${outName}`})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/edit',auth,async(req,res)=>{try{const name=path.basename(String(req.body.mediaUrl||'').split('/').pop()),src=mediaPath(name),outName=safeName('mp4'),vf=[];if(req.body.scale)vf.push(`scale=${String(req.body.scale).replace(/[^0-9:x]/g,'')}`);if(req.body.fps)vf.push(`fps=${Math.max(1,Math.min(60,Number(req.body.fps)))}`);const args=['-i',src];if(vf.length)args.push('-vf',vf.join(','));args.push('-c:v','libx264','-c:a','aac',path.join(MEDIA,outName));await ffmpeg(args);res.json({mediaUrl:`/api/media/file/${outName}`})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/compose',auth,async(req,res)=>{try{const v=mediaPath(path.basename(String(req.body.videoUrl||'').split('/').pop())),a=req.body.audioUrl?mediaPath(path.basename(String(req.body.audioUrl).split('/').pop())):null,outName=safeName('mp4'),args=['-i',v];if(a)args.push('-i',a);args.push('-map','0:v:0');if(a)args.push('-map','1:a:0');else args.push('-map','0:a?');args.push('-c:v','libx264','-c:a','aac','-shortest',path.join(MEDIA,outName));await ffmpeg(args);res.json({mediaUrl:`/api/media/file/${outName}`})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/jobs/:id/cancel',auth,async(req,res)=>{try{const j=db.jobs.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!j)return res.status(404).json({error:'Job not found.'});if(j.provider==='replicate')return res.status(501).json({error:'Replicate cancellation adapter removed in V15; use the configured provider API.'});res.json({status:'unsupported'})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/fans/checkout',auth,(req,res)=>{if(!process.env.PAYMENT_CHECKOUT_URL)return res.status(503).json({error:'Official payment checkout is not configured.'});res.json({url:process.env.PAYMENT_CHECKOUT_URL})});
app.post('/api/payments/webhook',(req,res)=>{const secret=process.env.PAYMENT_WEBHOOK_SECRET;if(secret){const sig=req.get('x-payment-signature')||'';const raw=req.rawBody||Buffer.from(JSON.stringify(req.body||{}));const expected=hmac(secret,raw);if(!sig||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return res.status(401).json({error:'Invalid webhook signature.'})}const{userId,status,plan}=req.body||{},u=db.users.find(x=>x.id===userId);if(u&&status==='paid'){u.premium=plan==='premium'||plan==='pro';u.fans=Math.max(u.fans,Number(req.body.fans||0));db.payments.push({userId,status,plan,at:now()});save()}res.json({ok:true})});
app.get('/api/apk/source.zip',(req,res)=>{const root=path.join(__dirname,'android');res.attachment('FanMakerAI-Android-V15.zip');const a=archiver('zip');a.on('error',()=>res.status(500).end());a.pipe(res);a.directory(root,false);a.finalize()});
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Server error'})});
app.listen(port,()=>console.log(`FanMakerAI V15 running on ${process.env.PUBLIC_BASE_URL||`http://localhost:${port}`}`));
