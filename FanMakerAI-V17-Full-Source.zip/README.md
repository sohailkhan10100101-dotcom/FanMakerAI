# FanMakerAI Ultimate V15

V15 is the consolidated production-oriented build of FanMakerAI. It keeps the FF + fan identity and focuses on real server-side integrations rather than fake generation timers.

## Included
- ChatGPT-style multilingual assistant with OpenAI Responses API + web search
- Prompt Studio
- OpenAI image generation adapter
- OpenAI video job adapter
- OpenAI TTS
- Licensed external music-provider adapter
- Authenticated media library and uploads
- Persistent JSON storage with atomic writes
- Session authentication, quotas and API rate limiting
- Server-side watermarking and FFmpeg editing/composition
- Payment checkout + signed webhook hook
- Owner diagnostics
- Android WebView source project (V15)
- Docker deployment with FFmpeg

## What V15 can and cannot make self-contained
AI providers, payment processors and hosting are external services. No code package can legitimately create provider accounts, billing credentials, or a live production server without those external accounts. V15 therefore includes the real adapters and a configuration/diagnostics path instead of pretending these services are live.

## Quick start
1. Copy `.env.example` to `.env`.
2. Set `OPENAI_API_KEY` and the model/provider values appropriate to your account.
3. Set a strong `ADMIN_PASSWORD`, `ADMIN_API_TOKEN`, and `PAYMENT_WEBHOOK_SECRET`.
4. Install Node 20+ dependencies: `npm install`.
5. Install FFmpeg, or use the supplied Dockerfile.
6. Run `npm run doctor` then `npm start`.
7. Open the server URL and create/login to an account.

## Docker
`docker build -t fanmakerai:v15 .`
`docker run --env-file .env -p 3000:3000 -v fanmakerai-data:/app/data fanmakerai:v15`

## Android
Set `FANMAKERAI_SERVER` in `android/app/build.gradle` to your HTTPS production server. The project is source code, not a pre-signed release APK. Android release packages must be digitally signed with your own key before installation/distribution.

## Important provider notes
- `OPENAI_API_KEY` stays server-side and is never embedded in the Android client.
- Music is deliberately provider-neutral because a real music provider requires its own account, API contract and licensing terms.
- Payment is deliberately provider-neutral: set the official checkout URL and verify signed webhooks from your actual payment processor.
- Generated media is protected behind authenticated media routes rather than a public `/media` directory.

## Production checklist
- HTTPS reverse proxy
- Persistent `/app/data` volume or object storage/database
- Strong secrets, rotated regularly
- Backups for `data/db.json` and media
- Real payment provider webhook verification
- Real licensed music provider
- Android signing key / Play App Signing
- Monitoring and log collection
