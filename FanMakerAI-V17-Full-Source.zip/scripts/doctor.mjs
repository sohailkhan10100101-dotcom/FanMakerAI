import fs from 'fs';
import { execFileSync } from 'child_process';
const required=['server.js','public/index.html','android/app/build.gradle'];
const missing=required.filter(x=>!fs.existsSync(x));
let ffmpeg=false; try{execFileSync('ffmpeg',['-version'],{stdio:'ignore'});ffmpeg=true}catch{}
console.log(JSON.stringify({ok:missing.length===0,version:'15.0.0',missing,ffmpeg,node:process.version,env:{OPENAI_API_KEY:!!process.env.OPENAI_API_KEY,PAYMENT_CHECKOUT_URL:!!process.env.PAYMENT_CHECKOUT_URL,MUSIC_API_URL:!!process.env.MUSIC_API_URL}},null,2));
process.exit(missing.length?1:0);
