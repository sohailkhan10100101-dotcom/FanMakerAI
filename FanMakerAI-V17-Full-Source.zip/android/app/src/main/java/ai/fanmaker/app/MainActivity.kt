package ai.fanmaker.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color

class MainActivity: Activity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val w=WebView(this); w.setBackgroundColor(Color.rgb(8,3,15)); w.settings.javaScriptEnabled=true; w.settings.domStorageEnabled=true; w.settings.allowFileAccess=true; w.webViewClient=WebViewClient()
  w.loadUrl("https://YOUR-FANMAKERAI-SERVER.example/")
  setContentView(w)
 }
}
